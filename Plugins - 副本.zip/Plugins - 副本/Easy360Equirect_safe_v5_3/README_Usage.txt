Easy360Equirect (UE 5.4 / 5.5 / 5.6) — SAFE v5.3
================================================
- RDG/Compute: cubemap -> equirect, Mono / TB / SBS。
- PNG+FFmpeg 复用；可录 Audio（Submix）；Editor 面板。
- 原生 NVENC（D3D11 零拷）开关：EASY360_ENABLE_NVENC=1 并装 NVCodec SDK；当前桥为可编译占位。
- Pipe 编码 UI 已留位（示例代码未实现回读喂管）。

使用:
1) 解压到 YourProject/Plugins/Easy360Equirect/
2) 生成 VS 工程并编译 Development Editor (Win64)
3) 关卡里放置 AEqrCaptureActor；Window -> Easy360 打开面板；Start/Stop 录制。
