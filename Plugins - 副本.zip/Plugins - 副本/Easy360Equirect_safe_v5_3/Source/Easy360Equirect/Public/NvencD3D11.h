#pragma once
#include "CoreMinimal.h"
#if EASY360_ENABLE_NVENC
  #define WITH_EASY360_NVENC 1
#else
  #define WITH_EASY360_NVENC 0
#endif

#if WITH_EASY360_NVENC && PLATFORM_WINDOWS
#include <d3d11.h>
struct FEasyNvencInit {
  ID3D11Device* Device=nullptr;
  int Width=0, Height=0;
  int BitrateMbps=40;
  bool bH265=false;
};
class FEasyNvencD3D11 {
public:
  bool Initialize(const FEasyNvencInit& Init);
  bool EncodeFrame(ID3D11Texture2D* Texture);
  bool Finalize();
  FString GetOutBitstreamPath() const { return OutPath; }
private:
  FString OutPath;
  void* NvEncoder=nullptr; // SDK object placeholder
};
#else
struct FEasyNvencInit { void* Device=nullptr; int Width=0, Height=0; int BitrateMbps=40; bool bH265=false; };
class FEasyNvencD3D11 { public:
  bool Initialize(const FEasyNvencInit&){ UE_LOG(LogTemp,Warning,TEXT("[Easy360] NVENC disabled (EASY360_ENABLE_NVENC=0).")); return false; }
  bool EncodeFrame(void*){ return false; }
  bool Finalize(){ return false; }
  FString GetOutBitstreamPath() const { return FString(); }
};
#endif
