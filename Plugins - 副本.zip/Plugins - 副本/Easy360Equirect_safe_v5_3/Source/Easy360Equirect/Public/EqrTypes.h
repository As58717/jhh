#pragma once
#include "CoreMinimal.h"
#include "EqrTypes.generated.h"

UENUM(BlueprintType)
enum class EEqrStereoMode : uint8
{
    Mono UMETA(DisplayName="Mono"),
    StereoSBS UMETA(DisplayName="Stereo Side-by-Side"),
    StereoTB UMETA(DisplayName="Stereo Top-Bottom")
};
