using UnrealBuildTool;
using System.IO;

public class Easy360Equirect : ModuleRules
{
    public Easy360Equirect(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core","CoreUObject","Engine","RenderCore","RHI","Projects","AudioMixer"
        });
        PrivateDependencyModuleNames.AddRange(new string[] { "Renderer" });

        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            PublicDefinitions.Add("EASY360_PLATFORM_WIN64=1");
            // 没有 NVENC SDK 就改 0；有 SDK 则放 1 并配置包含/库路径
            PublicDefinitions.Add("EASY360_ENABLE_NVENC=1");

            string NvInc = Path.Combine(ModuleDirectory, "../../ThirdParty/NvCodec/include");
            string NvLib = Path.Combine(ModuleDirectory, "../../ThirdParty/NvCodec/lib/x64");
            PublicIncludePaths.Add(NvInc);
            PublicAdditionalLibraries.Add(Path.Combine(NvLib, "nvEncodeAPI64.lib"));
        }
        else
        {
            PublicDefinitions.Add("EASY360_PLATFORM_WIN64=0");
            PublicDefinitions.Add("EASY360_ENABLE_NVENC=0");
        }
    }
}
