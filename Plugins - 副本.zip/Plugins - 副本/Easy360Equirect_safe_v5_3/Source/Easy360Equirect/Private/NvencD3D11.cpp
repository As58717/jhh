#include "NvencD3D11.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"
#include "HAL/FileManager.h"
#if WITH_EASY360_NVENC && PLATFORM_WINDOWS
bool FEasyNvencD3D11::Initialize(const FEasyNvencInit& Init){
  if(!Init.Device||Init.Width<=0||Init.Height<=0) return false;
  const FString Stamp=FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
  OutPath=FPaths::Combine(FPaths::ProjectSavedDir(),TEXT("Movies"),TEXT("Easy360"),Stamp, TEXT("nvenc.h264"));
  IFileManager::Get().MakeDirectory(*FPaths::GetPath(OutPath),true);
  UE_LOG(LogTemp,Log,TEXT("[Easy360] NVENC init (stub). Out=%s"), *OutPath);
  return true;
}
bool FEasyNvencD3D11::EncodeFrame(ID3D11Texture2D* Tex){ return Tex!=nullptr; }
bool FEasyNvencD3D11::Finalize(){ UE_LOG(LogTemp,Log,TEXT("[Easy360] NVENC finalize (stub).")); return true; }
#endif
