#include "EqrCaptureActor.h"
#include "Components/SceneCaptureComponentCube.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/TextureRenderTargetCube.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"
#include "HAL/PlatformProcess.h"
#include "AudioMixerBlueprintLibrary.h"
#include "EqrRenderer.h"
#include "Engine/Engine.h"

AEqrCaptureActor::AEqrCaptureActor(){
  PrimaryActorTick.bCanEverTick=true;
  RootComponent=CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

  LeftCapture=CreateDefaultSubobject<USceneCaptureComponentCube>(TEXT("LeftCapture"));
  LeftCapture->SetupAttachment(RootComponent);
  LeftCapture->bCaptureEveryFrame=false; LeftCapture->bCaptureOnMovement=false; LeftCapture->CaptureSource=ESceneCaptureSource::SCS_FinalColorHDR;

  RightCapture=CreateDefaultSubobject<USceneCaptureComponentCube>(TEXT("RightCapture"));
  RightCapture->SetupAttachment(RootComponent);
  RightCapture->bCaptureEveryFrame=false; RightCapture->bCaptureOnMovement=false; RightCapture->CaptureSource=ESceneCaptureSource::SCS_FinalColorHDR;

  LeftCubeRT = NewObject<UTextureRenderTargetCube>(this);
  LeftCubeRT->RenderTargetFormat=RTF_RGBA16f; LeftCubeRT->InitAutoFormat(1024); LeftCubeRT->bAutoGenerateMips=false; LeftCubeRT->UpdateResourceImmediate(true);
  LeftCapture->TextureTarget=LeftCubeRT;

  RightCubeRT = NewObject<UTextureRenderTargetCube>(this);
  RightCubeRT->RenderTargetFormat=RTF_RGBA16f; RightCubeRT->InitAutoFormat(1024); RightCubeRT->bAutoGenerateMips=false; RightCubeRT->UpdateResourceImmediate(true);
  RightCapture->TextureTarget=RightCubeRT;

  EquirectRT = NewObject<UTextureRenderTarget2D>(this);
  EquirectRT->RenderTargetFormat=ETextureRenderTargetFormat::RTF_RGBA16f;
  EquirectRT->InitAutoFormat(Width, Height);
  EquirectRT->bAutoGenerateMips=false; EquirectRT->UpdateResourceImmediate(true);
}

void AEqrCaptureActor::BeginPlay(){ Super::BeginPlay(); FrameInterval=1.0/FMath::Max(1.0f,TargetFPS); }

void AEqrCaptureActor::EnsureTargets(){
  const int32 Face=FMath::Max(512, Width/2);
  LeftCubeRT->InitAutoFormat(Face); LeftCubeRT->UpdateResourceImmediate(true);
  RightCubeRT->InitAutoFormat(Face); RightCubeRT->UpdateResourceImmediate(true);

#if EASY360_ENABLE_NVENC
  EquirectRT->RenderTargetFormat = (bUseNvenc ? ETextureRenderTargetFormat::RTF_RGBA8 : ETextureRenderTargetFormat::RTF_RGBA16f);
#else
  EquirectRT->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA16f;
#endif
  EquirectRT->InitAutoFormat(Width,Height); EquirectRT->UpdateResourceImmediate(true);
}

void AEqrCaptureActor::BuildSessionPaths(){
  FString Base=OutputDir; if(Base.IsEmpty()) Base=FPaths::Combine(FPaths::ProjectSavedDir(),TEXT("Movies"),TEXT("Easy360"));
  const FString Stamp=FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
  CurrentSessionDir=FPaths::Combine(Base,Stamp);
  IPlatformFile& PF=FPlatformFileManager::Get().GetPlatformFile(); PF.CreateDirectoryTree(*CurrentSessionDir);
  PngPattern=FPaths::Combine(CurrentSessionDir,TEXT("frame_%06d.png"));
  MoviePath =FPaths::Combine(CurrentSessionDir,TEXT("output.mp4"));
  AudioWavPath=FPaths::Combine(CurrentSessionDir,TEXT("audio.wav"));
}

FString AEqrCaptureActor::ResolveFFmpeg() const{
  if(!FFmpegExePath.IsEmpty() && FPaths::FileExists(FFmpegExePath)) return FFmpegExePath;
  if(FPlatformProcess::ExecutableExists(TEXT("ffmpeg"))) return TEXT("ffmpeg");
  TArray<FString> C; C.Add(TEXT("C:/ffmpeg/bin/ffmpeg.exe")); C.Add(TEXT("C:/Program Files/ffmpeg/bin/ffmpeg.exe")); C.Add(TEXT("C:/Program Files (x86)/ffmpeg/bin/ffmpeg.exe"));
  for(const FString& P : C) if(FPaths::FileExists(P)) return P;
  return TEXT("");
}

void AEqrCaptureActor::StartAudioRecord(){ if(!bRecordAudio) return; UAudioMixerBlueprintLibrary::StartRecordingOutput(this,0,SubmixToRecord); }
void AEqrCaptureActor::StopAudioRecord(){ if(!bRecordAudio) return;
  UAudioMixerBlueprintLibrary::StopRecordingOutput(this,EAudioRecordingExportType::WavFile,TEXT("audio"),CurrentSessionDir,nullptr); }

bool AEqrCaptureActor::WaitForAudioReady() const{
  const double End = FPlatformTime::Seconds() + 2.0;
  while(FPlatformTime::Seconds()<End){
    const int64 s1 = IFileManager::Get().FileSize(*AudioWavPath);
    if(s1>0){
      FPlatformProcess::Sleep(0.1f);
      const int64 s2 = IFileManager::Get().FileSize(*AudioWavPath);
      if(s2==s1) return true;
    }else{
      FPlatformProcess::Sleep(0.1f);
    }
  }
  return false;
}

void AEqrCaptureActor::StartCapture(){
  Width=FMath::Max(64,Width); Height=FMath::Max(32,Height);
  if(Width%2) ++Width; if(Height%2) ++Height;
  EnsureTargets();
  bCapturing=true; Accum=0.0; FrameIndex=0;
  if(bRecordSequence || bUseNvenc || bPipeEncode) BuildSessionPaths();
  StartAudioRecord();
  NvencStartIfNeeded();
}

void AEqrCaptureActor::StopCapture(){
  bCapturing=false;
  StopAudioRecord();
  if(bRecordAudio){ WaitForAudioReady(); }

  if(bUseNvenc && bNvencActive){ NvencStop(); }
  if(bRecordSequence && FrameIndex>0){ RunFFmpegMux(); }
}

void AEqrCaptureActor::Tick(float dt){
  Super::Tick(dt); if(!bCapturing) return;
  Accum+=dt;
  while(Accum>=FrameInterval){
    Accum-=FrameInterval;
    CaptureOnceAndConvert();

    if(bRecordSequence){
      FlushRenderingCommands();
      const FString Path=FPaths::Combine(CurrentSessionDir,FString::Printf(TEXT("frame_%06lld.png"),FrameIndex));
      UKismetRenderingLibrary::ExportRenderTarget(this,EquirectRT,Path); ++FrameIndex;
    }
    if(bUseNvenc && bNvencActive){
      FlushRenderingCommands();
      NvencSubmitFrame();
    }
    // bPipeEncode: 此示例未实现回读喂管，可后续扩展
  }
}

void AEqrCaptureActor::CaptureOnceAndConvert(){
  const float HalfIPD = (IPDcm*0.01f)*0.5f;
  LeftCapture->SetWorldLocation(GetActorLocation() + GetActorRightVector()*(-HalfIPD));
  RightCapture->SetWorldLocation(GetActorLocation()+ GetActorRightVector()*(+HalfIPD));
  LeftCapture->SetWorldRotation(GetActorRotation());
  RightCapture->SetWorldRotation(GetActorRotation());

  LeftCapture->CaptureScene();
  if(StereoMode!=EEqrStereoMode::Mono) RightCapture->CaptureScene();

  if(StereoMode==EEqrStereoMode::Mono){
    FTextureRHIRef L=LeftCubeRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
    ConvertEyeToRegion(L,FIntRect(0,0,Width,Height));
  }else if(StereoMode==EEqrStereoMode::StereoTB){
    const int32 HalfH=Height/2;
    FTextureRHIRef L=LeftCubeRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
    FTextureRHIRef R=RightCubeRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
    ConvertEyeToRegion(L,FIntRect(0,0,Width,HalfH));
    ConvertEyeToRegion(R,FIntRect(0,HalfH,Width,Height));
  }else{ // SBS
    const int32 HalfW=Width/2;
    FTextureRHIRef L=LeftCubeRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
    FTextureRHIRef R=RightCubeRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
    ConvertEyeToRegion(L,FIntRect(0,0,HalfW,Height));
    ConvertEyeToRegion(R,FIntRect(HalfW,0,Width,Height));
  }
}

void AEqrCaptureActor::ConvertEyeToRegion(FTextureRHIRef CubeRHI, const FIntRect& Region){
  const FMatrix44f Rot=FMatrix44f::Identity;
  FTextureRHIRef Out=EquirectRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
  ENQUEUE_RENDER_COMMAND(Easy360_ConvertEye)([CubeRHI,Out,Region,Rot](FRHICommandListImmediate& RHICmdList){
    EqrRenderer::ConvertCubeToEquirect_RenderThread(RHICmdList, CubeRHI, Out, Region, Rot);
  });
}

void AEqrCaptureActor::NvencStartIfNeeded(){
#if EASY360_ENABLE_NVENC && PLATFORM_WINDOWS
  if(!bUseNvenc){ bNvencActive=false; return; }

  if (!GDynamicRHI || FCString::Stricmp(GDynamicRHI->GetName(), TEXT("D3D11")) != 0) {
      UE_LOG(LogTemp, Warning, TEXT("[Easy360] NVENC requires D3D11, current RHI: %s"),
             GDynamicRHI ? GDynamicRHI->GetName() : TEXT("None"));
      bNvencActive=false; return;
  }

  FTextureRHIRef Out=EquirectRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
  void* NativeRes = Out->GetNativeResource();
  if(!NativeRes){ UE_LOG(LogTemp,Warning,TEXT("[Easy360] NVENC: Not D3D11 texture.")); bNvencActive=false; return; }
  ID3D11Texture2D* Tex = reinterpret_cast<ID3D11Texture2D*>(NativeRes);
  ID3D11Device* Dev=nullptr; Tex->GetDevice(&Dev);
  if(!Dev){ UE_LOG(LogTemp,Warning,TEXT("[Easy360] NVENC: No D3D11 device.")); bNvencActive=false; return; }

  FEasyNvencInit Init; Init.Device=Dev; Init.Width=Width; Init.Height=Height; Init.BitrateMbps=NvencBitrateMbps; Init.bH265=false;
  const bool ok = NvencEncoder.Initialize(Init);
  Dev->Release();
  if(ok){ bNvencActive=true; NvencBitstreamPath=NvencEncoder.GetOutBitstreamPath(); }
  else { bNvencActive=false; }
#else
  bNvencActive=false;
#endif
}

void AEqrCaptureActor::NvencSubmitFrame(){
#if EASY360_ENABLE_NVENC && PLATFORM_WINDOWS
  if(!bNvencActive) return;
  FTextureRHIRef Out=EquirectRT->GameThread_GetRenderTargetResource()->GetRenderTargetTexture();
  ID3D11Texture2D* Tex = reinterpret_cast<ID3D11Texture2D*>(Out->GetNativeResource());
  NvencEncoder.EncodeFrame(Tex);
#endif
}

void AEqrCaptureActor::NvencStop(){
#if EASY360_ENABLE_NVENC && PLATFORM_WINDOWS
  if(!bNvencActive) return;
  NvencEncoder.Finalize();

  const FString FfmpegRaw = ResolveFFmpeg(); if(FfmpegRaw.IsEmpty()){ UE_LOG(LogTemp,Warning,TEXT("[Easy360] ffmpeg not found for NVENC mux.")); return; }
  const FString FfmpegExe = FString::Printf(TEXT("\"%s\""), *FfmpegRaw);
  const bool bHasAudio = IFileManager::Get().FileExists(*AudioWavPath);

  FString OutMP4 = MoviePath.IsEmpty()? FPaths::ChangeExtension(NvencBitstreamPath, TEXT("mp4")) : MoviePath;
  const FString In264 = FString::Printf(TEXT("\"%s\""), *NvencBitstreamPath);
  const FString OutQ  = FString::Printf(TEXT("\"%s\""), *OutMP4);
  FString Args;
  if(bHasAudio){
    const FString WavQ = FString::Printf(TEXT("\"%s\""), *AudioWavPath);
    Args = FString::Printf(TEXT("-y -i %s -i %s -c:v copy -c:a aac -b:a 192k %s"), *In264, *WavQ, *OutQ);
  }else{
    Args = FString::Printf(TEXT("-y -i %s -c:v copy %s"), *In264, *OutQ);
  }
  int32 RC=0; FProcHandle P=FPlatformProcess::CreateProc(*FfmpegExe,*Args,true,false,false,nullptr,0,nullptr,nullptr);
  if(P.IsValid()){ FPlatformProcess::WaitForProc(P); FPlatformProcess::GetProcReturnCode(P,RC); FPlatformProcess::CloseProc(P); }
  if(RC!=0) UE_LOG(LogTemp,Warning,TEXT("[Easy360] NVENC mux failed rc=%d"),RC); else UE_LOG(LogTemp,Log,TEXT("[Easy360] NVENC mux done: %s"),*OutMP4);
#endif
}

void AEqrCaptureActor::RunFFmpegMux() const{
  const FString FfmpegRaw=ResolveFFmpeg(); if(FfmpegRaw.IsEmpty()){ UE_LOG(LogTemp,Warning,TEXT("[Easy360] ffmpeg not found.")); return; }
  const FString FfmpegExe = FString::Printf(TEXT("\"%s\""), *FfmpegRaw);
  const bool bHasAudio=IFileManager::Get().FileExists(*AudioWavPath);

  const FString InPng = FString::Printf(TEXT("\"%s\""), *PngPattern);
  const FString OutQ  = FString::Printf(TEXT("\"%s\""), *MoviePath);

  FString Args = FString::Printf(TEXT("-y -r %.3f -i %s "), TargetFPS, *InPng);
  if(bHasAudio){
    const FString WavQ = FString::Printf(TEXT("\"%s\""), *AudioWavPath);
    Args += FString::Printf(TEXT("-i %s "), *WavQ);
  }
  Args += FString::Printf(TEXT("-c:v libx264 -crf %d -pix_fmt yuv420p "), FMath::Clamp(FFmpegCRF, 0, 35));
  if(bHasAudio) Args += TEXT("-c:a aac -b:a 192k ");
  Args += OutQ;

  int32 RC=0; FProcHandle P=FPlatformProcess::CreateProc(*FfmpegExe,*Args,true,false,false,nullptr,0,nullptr,nullptr);
  if(P.IsValid()){ FPlatformProcess::WaitForProc(P); FPlatformProcess::GetProcReturnCode(P,RC); FPlatformProcess::CloseProc(P); }
  if(RC!=0) UE_LOG(LogTemp,Warning,TEXT("[Easy360] ffmpeg rc=%d"),RC); else UE_LOG(LogTemp,Log,TEXT("[Easy360] mux done: %s"),*MoviePath);
}
